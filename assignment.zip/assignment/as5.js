var mvmv = false;
        var mvlmvl = false;
        var flfl = false;
        var bpbp = false;
        function bml(){
            if(mvmv == true){
                document.getElementById("favouritemovie").style.display="none";
                mvmv = false;
            }
            if(flfl == true){
                document.getElementById("favouriteleaders").style.display = "none";
                flfl = false;
            }
            if(bpbp == true){
                document.getElementById("bestplaces").style.display = "none";
                bpbp = false;
            }
            document.getElementById("favouritemovieleader").style.display="block";
            mvlmvl = true;
          
        }
        function fm(){
            if(mvlmvl == true){
                document.getElementById("favouritemovieleader").style.display="none";
                mvlmvl = false;   
            }
            if(flfl == true){
                document.getElementById("favouriteleaders").style.display = "none";
                flfl = false;
            }
            if(bpbp == true){
                document.getElementById("bestplaces").style.display = "none";
                bpbp = false;
            }
            document.getElementById("favouritemovie").style.display="block";
            mvmv = true;  
        }
        function fl(){
            if(mvmv == true){
                document.getElementById("favouritemovie").style.display="none";
                mvmv = false;
            }
            if(mvlmvl == true){
                document.getElementById("favouritemovieleader").style.display="none";
                mvlmvl = false;   
            }
            if(bpbp == true){
                document.getElementById("bestplaces").style.display = "none";
                bpbp = false;
            }
            document.getElementById("favouriteleaders").style.display = "block";
            flfl = true;
        }
        function bp(){
            if(mvmv == true){
                document.getElementById("favouritemovie").style.display="none";
                mvmv = false;
            }
            if(mvlmvl == true){
                document.getElementById("favouritemovieleader").style.display="none";
                mvlmvl = false;   
            }
            if(flfl == true){
                document.getElementById("favouriteleaders").style.display = "none";
                flfl = false;
            }

            document.getElementById("bestplaces").style.display = "block";
            bpbp = true;
        }
       